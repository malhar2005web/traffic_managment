import tensorflow as tf
import numpy as np

# Create and save a dummy model (only once needed)
def create_and_save_model():
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(10, activation='relu', input_shape=(1,)),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Dummy training data (vehicles vs green light time)
    x = np.array([0, 2, 5, 10, 15, 20, 25, 30], dtype=float)
    y = np.array([5, 6, 8, 12, 15, 18, 20, 20], dtype=float)

    model.fit(x, y, epochs=200, verbose=0)
    model.save('traffic_tf_model.h5')
    print("Model saved as 'traffic_tf_model.h5'")

# Uncomment to create once
# create_and_save_model()